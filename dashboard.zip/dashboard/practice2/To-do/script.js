document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('task');
    const addBtn = document.getElementById('add-btn');
    const taskList = document.getElementById('task-list');
    let taskNumber = 1; // Initialize the task number

    addBtn.addEventListener('click', function() {
        const taskText = taskInput.value.trim();
        if (taskText !== '') {
            createTask(taskText, taskNumber);
            taskInput.value = '';
            taskNumber++; // Increment the task number
        }
    });

    taskInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            const taskText = taskInput.value.trim();
            if (taskText !== '') {
                createTask(taskText, taskNumber);
                taskInput.value = '';
                taskNumber++; // Increment the task number
            }
        }
    });

    function createTask(taskText, taskNumber) {
        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            <span>${taskNumber}.</span>
            <span>${taskText}</span>
            <button class="delete-btn">Delete</button>
        `;

        taskItem.querySelector('.delete-btn').addEventListener('click', function() {
            taskItem.remove();
        });

        taskItem.addEventListener('click', function() {
            taskItem.classList.toggle('completed');
        });

        taskList.appendChild(taskItem);
    }
});
