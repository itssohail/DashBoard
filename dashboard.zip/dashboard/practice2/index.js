const express = require("express")
const bodyParser = require("body-parser");
const mysql = require("mysql")
let output;

const app = express();
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json());
app.use(express.static(__dirname+"/public"));

app.get("/",function(req,res){
    res.sendFile(__dirname+"/index.html");
})


app.post("/signup",function(req,res){
    console.log("CONNECTOION?");
    var mail = req.body.mail;
    var pass = req.body.pass;
    
    
    var con = mysql.createConnection({
        host : "localhost",
        user : "root",
        password : "ameer",
        database : "dashboard"
    });
    con.connect(function(err){
        if(err)
            throw err;
        console.log("connected");
    })
    var query = "SELECT * FROM users WHERE mail='"+mail+"'";
    con.query(query,function(err,result){
        if(err)
            throw err;
        if(result.length===1){
            return res.send("Exist");
        }else{
            query = "INSERT INTO users(mail,password) VALUES("+"'"+mail+"'"+","+"'"+pass+"'"+")";
            con.query(query,function(err,result){
                if(err)
                    throw err;
                console.log("successful insert");
                return res.send("new");
            });
        }
    })
    
});

app.post("/signin",function(req,res){
    var mail = req.body.mail;
    var pass = req.body.pass;
    var query = "SELECT * FROM users WHERE mail="+"'"+mail+"' and password='"+pass+"'";
    var con = mysql.createConnection({
        host : "localhost",
        user : "root",
        password : "ameer",
        database : "dashboard"
    });
    con.connect(function(err){
        if(err)
            throw err;
        console.log("connected");
    })
    con.query(query,function(err,result){
        if(err)
            throw err;
        
        if(result.length===1){
            res.send("Success");
        }else{
            res.send("Failure");
        }


    });
});

app.get("/next",function(req,res){
    res.sendFile(__dirname+"/Welcome.html");
})
    
app.listen(2802,function(req,res){
    console.log("Server is running on port 2802........... ")
})